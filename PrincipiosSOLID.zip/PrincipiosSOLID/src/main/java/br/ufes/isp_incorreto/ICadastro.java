package br.ufes.isp_incorreto;

/**
 *
 * @author Alcebiades
 */
public interface ICadastro {

    public void validarDados();

    public void salvarDados();

    public void enviarEmail();
}
