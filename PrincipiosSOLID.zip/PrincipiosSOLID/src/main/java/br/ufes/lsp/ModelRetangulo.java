package br.ufes.lsp;

/**
 *
 * @author Alcebiades
 */
public class ModelRetangulo extends Paralelogramo{
    
    public ModelRetangulo(double altura, double largura) {
        super(altura, largura);
    }
    
}
