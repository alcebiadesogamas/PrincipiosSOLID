package br.ufes.dip_incorreto;

/**
 *
 * @author Alcebiades
 */
public class Principal {
    public static void main(String[] args) {
        Botao b = new Botao();
        b.acionar(1);
    }
    
    
    
}
