package br.ufes.dip_incorreto;

/**
 *
 * @author Alcebiades
 */
public class Lampada {

    public void ligar() {
        System.out.println("Ligado");
    }

    public void desligar() {
        System.out.println("Desligado");
    }

}
