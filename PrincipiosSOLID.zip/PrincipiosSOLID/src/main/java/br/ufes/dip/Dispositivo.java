    package br.ufes.dip;

/**
 *
 * @author Alcebiades
 */
public interface Dispositivo {
    public void ligar();
    public void desligar();
}
