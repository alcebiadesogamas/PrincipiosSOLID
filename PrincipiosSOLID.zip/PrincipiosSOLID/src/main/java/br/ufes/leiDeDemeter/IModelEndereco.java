package br.ufes.leiDeDemeter;

/**
 *
 * @author Alcebiades
 */
public interface IModelEndereco {

    public void setRua(String rua);

    public void setCep(String Cep);

    public String getCep();

    public String getRua();
}
