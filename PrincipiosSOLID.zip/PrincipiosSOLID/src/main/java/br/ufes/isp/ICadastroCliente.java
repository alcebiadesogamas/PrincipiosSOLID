package br.ufes.isp;

/**
 *
 * @author Alcebiades
 */
public interface ICadastroCliente {
    public void validarDados();

    public void salvarDados();

    public void enviarEmail();
}
