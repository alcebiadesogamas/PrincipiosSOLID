package br.ufes.isp;

/**
 *
 * @author Alcebiades
 */
public interface ICadastroProduto {

    public void validarDados();

    public void salvarDados();
}
