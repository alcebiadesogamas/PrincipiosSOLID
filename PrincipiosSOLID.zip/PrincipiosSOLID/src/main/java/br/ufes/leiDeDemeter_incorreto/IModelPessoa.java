package br.ufes.leiDeDemeter_incorreto;

/**
 *
 * @author Alcebiades
 */
public interface IModelPessoa {
    public void setCasa(ModelCasa casa);
    public ModelCasa getCasa();
}
