
package br.ufes.leiDeDemeter_incorreto;

/**
 *
 * @author Alcebiades
 */
public interface IModelEndereco {
    public void setRua(String rua);
    public void setCep(String cep);
    public String getRua();
    public String getCep();
}
