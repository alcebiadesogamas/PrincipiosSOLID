package br.ufes.leiDeDemeter_incorreto;

/**
 *
 * @author Alcebiades
 */
public interface IModelCasa {
    public void setEndereco(ModelEndereco endereco);
    public ModelEndereco getEndereco();
}
