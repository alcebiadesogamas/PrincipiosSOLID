package br.ufes.srp;

/**
 *
 * @author Alcebiades
 */
public class ClienteDAO {
    public void adcicionarCliente(ModelCliente cliente){
        //Operações para adicionar o cliente no banco de dados;
    }
}
